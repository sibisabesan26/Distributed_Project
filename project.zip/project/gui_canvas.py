from tkinter import *

blink_state = True


def draw_scene(nodes, canvas, aircraft_positions, current_aircraft):
    global blink_state

    canvas.delete("overlay")

    width = canvas.winfo_width() or 800
    height = canvas.winfo_height() or 600

    # --- Draw aircraft ---
    colors = ["red", "blue", "purple", "orange", "green", "cyan"]
    node_colors = {}

    for idx, (node_id, aircraft_list) in enumerate(sorted(aircraft_positions.items())):
        color = colors[idx % len(colors)]
        node_colors[node_id] = color

        for a in aircraft_list:
            if not a.get("visible", True):
                continue

            x, y = a.get("pos", [0, 0])
            symbol = a.get("symbol", "✈")

            canvas.create_text(
                x, y,
                text=symbol,
                font=("Arial", 20),
                fill=color,
                tags="overlay",
            )

            canvas.create_text(
                x,
                y - 22,
                text=f"Node {node_id}",
                font=("Arial", 11, "bold"),
                fill=color,
                tags="overlay",
            )

    # --- Active / Queued status at top ---
    active_nodes = [
        nid for nid, info in nodes.items()
        if info.get("state") in ("CRITICAL_SECTION", "RUNWAY")
    ]

    if active_nodes:
        status_text = "Active: " + ", ".join(map(str, active_nodes))
    else:
        status_text = "Active: None"

    queued = current_aircraft.get("queue", [])
    if queued:
        status_text += " | Queued: " + ", ".join(map(str, queued))

    canvas.create_text(
        width / 2,
        20,
        text=status_text,
        font=("Arial", 14),
        fill="black",
        tags="overlay",
    )

    # --- Tower roughly in the middle apron above the runway ---
    tower_x = width / 2
    tower_y = height * 0.45   # in the white area above runway

    canvas.create_text(
        tower_x,
        tower_y,
        text="Tower",
        font=("Arial", 14, "bold"),
        fill="black",
        tags="overlay",
    )

    if active_nodes:
        active_node = active_nodes[0]
        color = node_colors.get(active_node, "black")

        canvas.create_text(
            tower_x,
            tower_y + 20,
            text=f"Node {active_node}",
            font=("Arial", 12, "bold"),
            fill=color,
            tags="overlay",
        )

        if blink_state:
            canvas.create_oval(
                tower_x - 10, tower_y - 35,
                tower_x + 10, tower_y - 15,
                fill=color,
                outline=color,
                tags="overlay",
            )

    blink_state = not blink_state
