from flask import Flask, request, jsonify

app = Flask("Coordinator")

# Current token holder and waiting queue
token_holder = None
queue = []
queued_set = set()   # track nodes already in queue so we do not enqueue duplicates


@app.route("/request", methods=["POST"])
def handle_request():
    global token_holder, queue, queued_set
    data = request.get_json(force=True)
    node = data["node"]

    # If no token holder, grant immediately
    if token_holder is None:
        token_holder = node
        print(f"[Coordinator] Granting token immediately to node {node}")
        return jsonify({"granted": True})
    else:
        # Otherwise, queue the request if not already queued
        if node not in queued_set:
            queue.append(node)
            queued_set.add(node)
            print(f"[Coordinator] Node {node} enqueued for token. Queue = {queue}")
        else:
            print(f"[Coordinator] Node {node} already in queue. Queue = {queue}")
        return jsonify({"granted": False})


@app.route("/release", methods=["POST"])
def handle_release():
    global token_holder, queue, queued_set
    data = request.get_json(force=True)
    node = data["node"]

    if node != token_holder:
        print(f"[Coordinator] Node {node} tried to release but is not the holder (holder={token_holder})")
        return jsonify({"status": "ok"})

    # Move the token to the next node in the queue, if any
    if queue:
        next_node = queue.pop(0)
        queued_set.remove(next_node)
        print(f"[Coordinator] Moving token from {node} -> {next_node}. Remaining queue = {queue}")
        token_holder = next_node
    else:
        print(f"[Coordinator] Token released by {node}. No one is waiting; token is now free.")
        token_holder = None

    return jsonify({"status": "ok"})


@app.route("/status")
def status():
    """Expose current token holder and queue for controllers/GUI polling."""
    return jsonify({
        "token_holder": token_holder,
        "queue": queue
    })


if __name__ == "__main__":
    print("[Coordinator] Starting on port 6000")
    # threaded=True lets a node call /status while we are handling /request from another
    app.run(port=6000, debug=False, use_reloader=False, threaded=True)
