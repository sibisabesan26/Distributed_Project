from flask import Flask, jsonify
import threading
import time
import requests

app = Flask("Controller2")

CONTROLLER_ID = 2
COORDINATOR = "http://127.0.0.1:6000"

ROLE = "ARRIVAL"
REQUEST_OFFSET = 2.0   # Node 2 always first

# Geometry
RIGHT_APPROACH_X = 1300
APPROACH_Y = 380
RUNWAY_Y = 520
LEFT_RUNOFF_X = 180

UPDATE_DT = 0.25

state = "IDLE"
requested = False
start_time = None

aircraft = [{
    "id": f"N{CONTROLLER_ID}",
    "pos": [RIGHT_APPROACH_X, APPROACH_Y],
    "controller": CONTROLLER_ID,
    "trail": [],
    "symbol": "▼",
    "visible": True,
}]


def request_token():
    global state, requested
    try:
        resp = requests.post(
            f"{COORDINATOR}/request",
            json={"node": CONTROLLER_ID},
            timeout=2,
        )
        data = resp.json()
        granted = data.get("granted", False)
        requested = True
        if granted:
            state = "CRITICAL_SECTION"
            print(f"[Node {CONTROLLER_ID}] Got token immediately.")
        else:
            state = "WAITING"
            print(f"[Node {CONTROLLER_ID}] Requested token, queued.")
    except Exception as e:
        print(f"[Node {CONTROLLER_ID}] Error requesting token:", e)


def release_token():
    global state
    try:
        requests.post(
            f"{COORDINATOR}/release",
            json={"node": CONTROLLER_ID},
            timeout=2,
        )
    except Exception as e:
        print(f"[Node {CONTROLLER_ID}] Error releasing token:", e)
    state = "DONE"
    print(f"[Node {CONTROLLER_ID}] Landing complete, token released.")


def poll_for_token():
    global state
    if state != "WAITING":
        return
    try:
        r = requests.get(f"{COORDINATOR}/status", timeout=2)
        data = r.json()
        if data.get("token_holder") == CONTROLLER_ID:
            state = "CRITICAL_SECTION"
            print(f"[Node {CONTROLLER_ID}] Acquired token from queue.")
    except Exception as e:
        print(f"[Node {CONTROLLER_ID}] Error polling coordinator:", e)


def holding_step(ac):
    """Small oscillation on right side while waiting."""
    ac["symbol"] = "▼"
    vx = ac.get("vx", -2.0)
    x, _ = ac["pos"]
    x += vx
    if x < RIGHT_APPROACH_X - 60 or x > RIGHT_APPROACH_X + 20:
        vx = -vx
    ac["vx"] = vx
    ac["pos"] = [x, APPROACH_Y]


def landing_step(ac):
    """Approach from right, descend, then roll to left end and park."""
    x, y = ac["pos"]
    ac["symbol"] = "▼"

    # Descend to runway
    if y < RUNWAY_Y:
        y += 2

    # Move right -> left along runway
    x -= 5

    ac["pos"] = [x, y]

    # Park at 21 blast pad
    if x < LEFT_RUNOFF_X:
        ac["pos"] = [LEFT_RUNOFF_X, RUNWAY_Y]
        release_token()


def simulate():
    global start_time, state, requested
    start_time = time.time()
    print(f"[Node {CONTROLLER_ID}] Simulation started (ARRIVAL from right).")

    while True:
        now = time.time()
        elapsed = now - start_time
        ac = aircraft[0]

        if not requested and elapsed >= REQUEST_OFFSET:
            request_token()

        poll_for_token()

        if state in ("IDLE", "WAITING"):
            holding_step(ac)
        elif state == "CRITICAL_SECTION":
            landing_step(ac)
        elif state == "DONE":
            ac["symbol"] = "◀"
            ac["pos"] = [LEFT_RUNOFF_X, RUNWAY_Y]

        time.sleep(UPDATE_DT)


@app.route("/aircraft")
def get_aircraft():
    return jsonify(aircraft)


@app.route("/nodes")
def get_nodes():
    return jsonify({CONTROLLER_ID: {"state": state}})


if __name__ == "__main__":
    threading.Thread(target=simulate, daemon=True).start()
    print(f"[Node {CONTROLLER_ID}] HTTP server on port {5000 + CONTROLLER_ID}")
    app.run(port=5000 + CONTROLLER_ID,
            debug=False,
            use_reloader=False,
            threaded=True)
