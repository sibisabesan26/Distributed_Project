from flask import Flask, jsonify
import threading
import time
import requests

app = Flask("Controller4")

CONTROLLER_ID = 4
COORDINATOR = "http://127.0.0.1:6000"

ROLE = "ARRIVAL"

# Geometry for the 1472x704 airport image
RIGHT_APPROACH_X = 1200
APPROACH_Y = 380
RUNWAY_Y = 520
LEFT_RUNOFF_X = 180

UPDATE_DT = 0.25

state = "IDLE"          # "IDLE", "WAITING", "CRITICAL_SECTION", "DONE"
requested = False
activated = False
start_time = None

aircraft = [{
    "id": f"N{CONTROLLER_ID}",
    "pos": [RIGHT_APPROACH_X, APPROACH_Y],
    "controller": CONTROLLER_ID,
    "trail": [],
    "symbol": "▼",      # descending symbol
    "visible": False,   # hidden until Node 3 is using the runway
}]


def node3_in_critical_section():
    """
    Returns True when Node 3 is currently in CRITICAL_SECTION
    (i.e., it holds the runway token and is taking off).
    """
    try:
        r = requests.get("http://127.0.0.1:5003/nodes", timeout=1.0)
        data = r.json()
        info = data.get("3") or data.get(3)
        if info and info.get("state") == "CRITICAL_SECTION":
            return True
    except Exception:
        pass
    return False


def request_token():
    global state, requested
    try:
        resp = requests.post(
            f"{COORDINATOR}/request",
            json={"node": CONTROLLER_ID},
            timeout=2,
        )
        data = resp.json()
        granted = data.get("granted", False)
        requested = True
        if granted:
            state = "CRITICAL_SECTION"
            print(f"[Node {CONTROLLER_ID}] Got token immediately.")
        else:
            state = "WAITING"
            print(f"[Node {CONTROLLER_ID}] Requested token, queued.")
    except Exception as e:
        print(f"[Node {CONTROLLER_ID}] Error requesting token:", e)


def release_token():
    global state
    try:
        requests.post(
            f"{COORDINATOR}/release",
            json={"node": CONTROLLER_ID},
            timeout=2,
        )
    except Exception as e:
        print(f"[Node {CONTROLLER_ID}] Error releasing token:", e)
    state = "DONE"
    print(f"[Node {CONTROLLER_ID}] Landing complete, token released.")


def poll_for_token():
    global state
    if state != "WAITING":
        return
    try:
        r = requests.get(f"{COORDINATOR}/status", timeout=2)
        data = r.json()
        if data.get("token_holder") == CONTROLLER_ID:
            state = "CRITICAL_SECTION"
            print(f"[Node {CONTROLLER_ID}] Acquired token from queue.")
    except Exception as e:
        print(f"[Node {CONTROLLER_ID}] Error polling coordinator:", e)


def holding_step(ac):
    """
    Small back-and-forth motion on the right side while waiting.
    """
    ac["symbol"] = "▼"
    vx = ac.get("vx", -2.0)
    x, _ = ac["pos"]
    x += vx
    if x < RIGHT_APPROACH_X - 60 or x > RIGHT_APPROACH_X + 20:
        vx = -vx
    ac["vx"] = vx
    ac["pos"] = [x, APPROACH_Y]


def landing_step(ac):
    """
    Land from right to left:
    - descend to runway level
    - roll along runway to the 21 blast pad and park.
    """
    x, y = ac["pos"]
    ac["symbol"] = "▼"

    # Descend a bit faster so we get down quickly
    if y < RUNWAY_Y:
        y += 3

    # Move left faster so Node 4 is snappy
    x -= 7

    ac["pos"] = [x, y]

    if x < LEFT_RUNOFF_X:
        # Park exactly at blast pad
        ac["pos"] = [LEFT_RUNOFF_X, RUNWAY_Y]
        release_token()


def simulate():
    global start_time, state, requested, activated
    start_time = time.time()
    print(f"[Node {CONTROLLER_ID}] Simulation started (ARRIVAL last).")

    while True:
        ac = aircraft[0]

        # --- Activation logic ---
        # Only appear once Node 3 is actually taking off (has the token).
        if not activated:
            if node3_in_critical_section():
                activated = True
                ac["visible"] = True
                print(f"[Node {CONTROLLER_ID}] Activated while Node 3 is taking off.")
            else:
                time.sleep(UPDATE_DT)
                continue

        # Request token once active (so we enter the queue while Node 3 holds it)
        if not requested:
            request_token()

        poll_for_token()

        # --- Motion states ---
        if state in ("IDLE", "WAITING"):
            holding_step(ac)
        elif state == "CRITICAL_SECTION":
            landing_step(ac)
        elif state == "DONE":
            # Stay parked at 21 blast pad
            ac["symbol"] = "◀"
            ac["pos"] = [LEFT_RUNOFF_X, RUNWAY_Y]

        time.sleep(UPDATE_DT)


@app.route("/aircraft")
def get_aircraft():
    return jsonify(aircraft)


@app.route("/nodes")
def get_nodes():
    return jsonify({CONTROLLER_ID: {"state": state}})


if __name__ == "__main__":
    threading.Thread(target=simulate, daemon=True).start()
    print(f"[Node {CONTROLLER_ID}] HTTP server on port {5000 + CONTROLLER_ID}")
    app.run(port=5000 + CONTROLLER_ID,
            debug=False,
            use_reloader=False,
            threaded=True)
