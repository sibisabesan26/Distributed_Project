import subprocess
import time
import sys
import os

# Paths to your scripts
COORDINATOR = "coordinator.py"
NODE1 = "main_controller1.py"
NODE2 = "main_controller2.py"
NODE3 = "main_controller3.py"
NODE4 = "main_controller4.py"
GUI     = "gui_main.py"

processes = []


def launch(script, label, delay_after=0.0):
    """Launch a Python script as a separate process."""
    if not os.path.exists(script):
        print(f"[Launcher] WARNING: {label} script '{script}' not found.")
        return

    try:
        p = subprocess.Popen([sys.executable, script])
        processes.append(p)
        print(f"[Launcher] Started {label} ({script})")
        if delay_after > 0:
            time.sleep(delay_after)
    except Exception as e:
        print(f"[Launcher] Error starting {label}: {e}")


def main():
    print("[Launcher] Starting distributed air traffic control demo...")

    # Start coordinator first
    launch(COORDINATOR, "Coordinator", delay_after=1.5)

    # Start controllers (Node 2 lands first, Node 1 departs, Node 4 lands, Node 3 departs)
    launch(NODE1, "Controller 1", delay_after=0.5)
    launch(NODE2, "Controller 2", delay_after=0.5)
    launch(NODE3, "Controller 3", delay_after=0.5)
    launch(NODE4, "Controller 4", delay_after=0.5)

    # Start GUI last so all endpoints are up
    launch(GUI, "GUI", delay_after=0.0)

    print("[Launcher] All processes started.")
    print("[Launcher] Close the GUI window or press Ctrl+C here to stop everything.")

    try:
        while True:
            # Keep launcher alive; you could later add health checks here if needed
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[Launcher] Stopping all processes...")
        for p in processes:
            try:
                p.terminate()
            except Exception:
                pass
        print("[Launcher] Done.")


if __name__ == "__main__":
    main()
