from flask import Flask, jsonify
import threading
import time
import requests

app = Flask("Controller3")

CONTROLLER_ID = 3
COORDINATOR = "http://127.0.0.1:6000"

ROLE = "DEPARTURE"
REQUEST_OFFSET = 14.0   # Node 3 after Node 1

RIGHT_RUNOFF_X = 1350
LEFT_RUNOFF_X = 150
RUNWAY_Y = 520

UPDATE_DT = 0.25

state = "IDLE"
requested = False
start_time = None

aircraft = [{
    "id": f"N{CONTROLLER_ID}",
    # Node 3 slightly to the RIGHT, behind Node 1
    "pos": [RIGHT_RUNOFF_X - 20, RUNWAY_Y],
    "controller": CONTROLLER_ID,
    "trail": [],
    "symbol": "◀",
    "visible": True,
}]


def request_token():
    global state, requested
    try:
        resp = requests.post(
            f"{COORDINATOR}/request",
            json={"node": CONTROLLER_ID},
            timeout=2,
        )
        data = resp.json()
        granted = data.get("granted", False)
        requested = True
        if granted:
            state = "CRITICAL_SECTION"
            print(f"[Node {CONTROLLER_ID}] Got token immediately.")
        else:
            state = "WAITING"
            print(f"[Node {CONTROLLER_ID}] Requested token, queued.")
    except Exception as e:
        print(f"[Node {CONTROLLER_ID}] Error requesting token:", e)


def release_token():
    global state
    try:
        requests.post(
            f"{COORDINATOR}/release",
            json={"node": CONTROLLER_ID},
            timeout=2,
        )
    except Exception as e:
        print(f"[Node {CONTROLLER_ID}] Error releasing token:", e)
    state = "DONE"
    print(f"[Node {CONTROLLER_ID}] Departure complete, token released.")


def poll_for_token():
    global state
    if state != "WAITING":
        return
    try:
        r = requests.get(f"{COORDINATOR}/status", timeout=2)
        data = r.json()
        if data.get("token_holder") == CONTROLLER_ID:
            state = "CRITICAL_SECTION"
            print(f"[Node {CONTROLLER_ID}] Acquired token from queue.")
    except Exception as e:
        print(f"[Node {CONTROLLER_ID}] Error polling coordinator:", e)


def taxi_step(ac):
    """Wiggle on 03 blast pad while waiting."""
    ac["symbol"] = "◀"
    wiggle = ac.get("wiggle", -1)
    x, _ = ac["pos"]
    x += wiggle
    # wiggle around the new position (-20)
    if x < RIGHT_RUNOFF_X - 40 or x > RIGHT_RUNOFF_X - 10:
        wiggle = -wiggle
    ac["wiggle"] = wiggle
    ac["pos"] = [x, RUNWAY_Y]

def takeoff_step(ac):
    """Full-length 03→21 takeoff."""
    x, y = ac["pos"]

    if x > 320:
        ac["symbol"] = "◀"
        x -= 6
        y = RUNWAY_Y
    else:
        ac["symbol"] = "▲"
        x -= 6
        y -= 3

    ac["pos"] = [x, y]

    if x < LEFT_RUNOFF_X - 80:
        release_token()


def simulate():
    global start_time, state, requested
    start_time = time.time()
    print(f"[Node {CONTROLLER_ID}] Simulation started (DEPARTURE 03→21).")

    while True:
        now = time.time()
        elapsed = now - start_time
        ac = aircraft[0]

        if not requested and elapsed >= REQUEST_OFFSET:
            request_token()

        poll_for_token()

        if state in ("IDLE", "WAITING"):
            taxi_step(ac)
        elif state == "CRITICAL_SECTION":
            takeoff_step(ac)
        elif state == "DONE":
            x, y = ac["pos"]
            ac["symbol"] = "▲"
            ac["pos"] = [x - 2, max(150, y - 1)]

        time.sleep(UPDATE_DT)


@app.route("/aircraft")
def get_aircraft():
    return jsonify(aircraft)


@app.route("/nodes")
def get_nodes():
    return jsonify({CONTROLLER_ID: {"state": state}})


if __name__ == "__main__":
    threading.Thread(target=simulate, daemon=True).start()
    print(f"[Node {CONTROLLER_ID}] HTTP server on port {5000 + CONTROLLER_ID}")
    app.run(port=5000 + CONTROLLER_ID,
            debug=False,
            use_reloader=False,
            threaded=True)
