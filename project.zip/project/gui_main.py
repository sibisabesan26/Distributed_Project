# gui_main.py

import tkinter as tk
from tkinter import scrolledtext
import threading

from PIL import Image, ImageTk
from gui_update import start_update_loop

# CHANGE THIS to match your actual image filename
# e.g. "airport_layout.png" or "runway_taxiway.png"
BACKGROUND_FILE = "background.png"


def main():
    root = tk.Tk()
    root.title("Distributed Air Traffic Control")

    # --- Load background to know its size ---
    try:
        bg_image = Image.open(BACKGROUND_FILE)
        width, height = bg_image.size
        print(f"[GUI] Loaded {BACKGROUND_FILE} ({width}x{height})")
    except Exception as e:
        # If filename is wrong or image not found, you get the green fallback
        print(f"[GUI] Could not load {BACKGROUND_FILE}: {e}")
        width, height = 800, 600
        from PIL import Image as PILImage
        bg_image = PILImage.new("RGB", (width, height), "darkgreen")

    # Canvas matches image size
    canvas = tk.Canvas(root, width=width, height=height)
    canvas.pack()

    # Draw image once, tagged as "background"
    bg_photo = ImageTk.PhotoImage(bg_image)
    canvas.create_image(0, 0, image=bg_photo, anchor="nw", tags="background")
    canvas.bg_photo = bg_photo       # keep reference so it is not garbage collected

    # --- Message log at bottom ---
    log_frame = tk.Frame(root)
    log_frame.pack(side="bottom", fill="both", expand=True)

    log_widget = scrolledtext.ScrolledText(
        log_frame,
        wrap=tk.WORD,
        height=8,
        font=("Consolas", 10),
    )
    log_widget.pack(fill="both", expand=True)
    root.log_widget = log_widget

    # --- Start periodic update loop (no speed slider now) ---
    node_count = 4
    speed_multiplier = 1.0
    aircraft_positions = {}

    threading.Thread(
        target=start_update_loop,
        args=(root, canvas, node_count, speed_multiplier, aircraft_positions),
        daemon=True,
    ).start()

    root.mainloop()


def log_message(root, sender, receiver, content):
    """Append a line into the log window."""
    entry = f"[{sender} → {receiver}] {content}\n"
    root.log_widget.insert(tk.END, entry)
    root.log_widget.see(tk.END)


if __name__ == "__main__":
    main()
